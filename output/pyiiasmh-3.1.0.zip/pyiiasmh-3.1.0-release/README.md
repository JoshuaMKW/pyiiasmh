# pyiiasmh 3
The cross platform Gecko Code compiler, updated to Python 3.x

Usage of pyiiasmh 3 requires that you have installed Python 3.x and added it to your PATH. You also need to install PyQt5, which can be found here: https://pypi.org/project/PyQt5/
This can be done through cmd, as "pip install PyQt5", or as a manual install.

Once you have these things set up, simply run pyiiasmh.py using python (either in cmd or double clicking the file) and the program will boot.
